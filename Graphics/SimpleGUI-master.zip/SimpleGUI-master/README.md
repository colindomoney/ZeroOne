SimpleGUI
=========

Simple GUI template in Tkinter 

Or just the simplest GUI in the known Universe 

To open it:

 `python src/MainApp.py`

or 

 `./run` 


